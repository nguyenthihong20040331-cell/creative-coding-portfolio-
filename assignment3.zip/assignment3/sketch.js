let moveX = 0;
let jumpY = 0;
let faceColor;
let eyeX = 0;
let eyeY = 0;

function setup() {
  createCanvas(600, 400); // 캔버스 크기
  faceColor = color(255, 220, 180); // 얼굴 색
}

function draw() {
  background(220);

  // 좌우 움직임
  moveX = sin(frameCount * 0.05) * 20;

  push();
  translate(moveX, jumpY);

  // 얼굴
  fill(faceColor);
  ellipse(300, 200, 180, 220);

  // 머리카락
  fill(60, 30, 20);
  arc(300, 150, 200, 180, PI, TWO_PI);

  // 눈 (마우스 따라감)
  eyeX = map(mouseX, 0, width, -10, 10);
  eyeY = map(mouseY, 0, height, -10, 10);

  fill(255);
  ellipse(260, 190, 40, 25);
  ellipse(340, 190, 40, 25);

  fill(0);
  ellipse(260 + eyeX, 190 + eyeY, 15, 15);
  ellipse(340 + eyeX, 190 + eyeY, 15, 15);

  // 안경
  noFill();
  stroke(0);
  rect(240, 175, 40, 30);
  rect(320, 175, 40, 30);
  line(280, 190, 320, 190);

  // 코
  line(300, 200, 300, 230);

  // 입
  fill(255, 100, 120);
  arc(300, 250, 60, 30, 0, PI);

  // 볼
  fill(255, 150, 150);
  ellipse(240, 230, 30, 20);
  ellipse(360, 230, 30, 20);

  // 몸
  fill(100, 140, 220);
  rect(260, 310, 80, 80);

  pop();
}

// 마우스 클릭 → 얼굴 색 변경
function mousePressed() {
  faceColor = color(random(255), random(255), random(255));
}

// 키보드 → 점프
function keyPressed() {
  jumpY = -30;
}

// 키보드 떼면 원위치
function keyReleased() {
  jumpY = 0;
}

// S 누르면 GIF 저장
function keyTyped() {
  if (key === 's' || key === 'S') {
    saveGif('character', 5);
  }
}