function setup() {
  createCanvas(600, 400);
  colorMode(HSB);
}

function draw() {

  // 하늘
  background(210, 30, 100);

  // 잔디
  fill(110, 50, 75);
  rect(0, 350, 600, 50);

  // 태양
  fill(50, 100, 100);
  circle(500, 80, 60);

  // 첫 번째 집
  drawHouse1();

  // 두 번째 집
  drawHouse2();

  // 세 번째 집
  drawHouse3();
}

function drawHouse1() {

  fill(0, 40, 70);
  rect(60, 220, 80, 180);

  fill(0, 45, 45);
  triangle(60, 220, 140, 220, 100, 180);

  fill(0, 0, 100);

  rect(75, 260, 15, 15);
  rect(105, 280, 15, 15);
}

function drawHouse2() {

  fill(150, 40, 70);
  rect(170, 250, 90, 150);

  fill(150, 45, 45);
  triangle(170, 250, 260, 250, 215, 210);

  fill(0, 0, 100);

  rect(190, 280, 15, 15);
  rect(220, 300, 15, 15);
}

function drawHouse3() {

  fill(240, 25, 75);
  rect(300, 200, 100, 200);

  fill(240, 25, 55);
  triangle(300, 200, 400, 200, 350, 160);

  fill(0, 0, 100);

  rect(320, 230, 15, 15);
  rect(360, 260, 15, 15);
}