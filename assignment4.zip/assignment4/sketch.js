let capturing = false;
function setup() {
  createCanvas(600, 400);
  colorMode(HSB);
}

function draw() {

  // 하늘 색 변화
  let skyColor = map(sin(frameCount * 0.01), -1, 1, 180, 230);
  background(skyColor, 30, 100);

  // 잔디
  fill(110, 50, 75);
  rect(0, 350, 600, 50);

  // 태양 움직임 + 크기 변화
  let sunX = 500 + sin(frameCount * 0.02) * 40;
  let sunSize = 60 + sin(frameCount * 0.05) * 10;

  fill(50, 100, 100);
  circle(sunX, 80, sunSize);

  // 첫 번째 집
  drawHouse1();

  // 두 번째 집
  drawHouse2();

  // 세 번째 집
  drawHouse3();
}

function drawHouse1() {

  let scaleValue = 1 + sin(frameCount * 0.03) * 0.03;

  push();
  translate(0, 0);
  scale(scaleValue);

  fill(0, 40, 70);
  rect(60, 220, 80, 180);

  fill(0, 45, 45);
  triangle(60, 220, 140, 220, 100, 180);

  // 창문 색 변화
  let w = map(sin(frameCount * 0.05), -1, 1, 70, 100);
  fill(0, 0, w);

  rect(75, 260, 15, 15);
  rect(105, 280, 15, 15);

  pop();
}

function drawHouse2() {

  let moveY = sin(frameCount * 0.03) * 5;

  push();
  translate(220, moveY);

  fill(30, 60, 90);
  rect(0, 240, 90, 160);

  fill(20, 80, 50);
  triangle(0, 240, 90, 240, 45, 190);

  fill(60, 20, 100);
  rect(20, 270, 20, 20);
  rect(50, 300, 20, 20);

  pop();
}

function drawHouse3() {

  let moveX = sin(frameCount * 0.02) * 5;

  push();
  translate(400 + moveX, 0);

  fill(200, 50, 80);
  rect(0, 230, 100, 170);

  fill(210, 60, 40);
  triangle(0, 230, 100, 230, 50, 180);

  fill(0, 0, 100);
  rect(20, 260, 20, 20);
  rect(60, 300, 20, 20);

  pop();
}
function keyPressed() {
  if (key === 's' || key === 'S') {
    saveGif('artworkGIF', 5);
  }
}