<!DOCTYPE html>  
<html lang="ko">  
<head>  
<meta charset="UTF-8">  
<meta name="viewport" content="width=device-width, initial-scale=1.0">  
  
<title>Creative Coding Portfolio</title>  
  
<style>  
  
body{  
  margin:0;  
  padding:40px;  
  background:#111;  
  color:white;  
  font-family:sans-serif;  
}  
  
h1{  
  text-align:center;  
  font-size:48px;  
  margin-bottom:10px;  
}  
  
p{  
  text-align:center;  
  color:#aaa;  
  margin-bottom:40px;  
}  
  
.grid{  
  display:grid;  
  grid-template-columns:1fr 1fr;  
  gap:25px;  
}  
  
.card{  
  background:#1e1e1e;  
  padding:20px;  
  border-radius:20px;  
}  
  
.card h2{  
  margin-bottom:15px;  
}  
  
iframe{  
  width:100%;  
  height:400px;  
  border:none;  
  border-radius:10px;  
  background:black;  
}  
  
</style>  
</head>  
  
<body>  
  
<h1>Creative Coding Portfolio</h1>  
<p>p5.js Assignments</p>  
  
<div class="grid">  
  
  <div class="card">  
    <h2>과제 1</h2>  
    <iframe src="./assignment1/index.html"></iframe>  
  </div>  
  
  <div class="card">  
    <h2>과제 4</h2>  
    <iframe src="./assignment4/index.html"></iframe>  
  </div>  
  
  <div class="card">  
    <h2>과제 2</h2>  
    <iframe src="./assignment2/index.html"></iframe>  
  </div>  
  
  <div class="card">  
    <h2>과제 3</h2>  
    <iframe src="./assignment3/index.html"></iframe>  
  </div>  
  
</div>  
  
</body>  
</html>  
