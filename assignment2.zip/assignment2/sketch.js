function setup() {
  
  createCanvas(600, 400);
  
  background(220);
  
  
  
  // face
  
  fill(255, 220, 180);
  
  ellipse(300, 200, 180, 220);
  
  
  
  // hair
  
  fill(60, 30, 20);
  
  arc(300, 150, 200, 180, PI, TWO_PI);
  
  
  
  // eyes
  
  fill(255);
  
  ellipse(260, 190, 40, 25);
  
  ellipse(340, 190, 40, 25);
  
  
  
  fill(0);
  
  ellipse(260, 190, 15, 15);
  
  ellipse(340, 190, 15, 15);
  
  
  
  // glasses
  
  noFill();
  
  stroke(0);
  
  rect(240, 175, 40, 30);
  
  rect(320, 175, 40, 30);
  
  line(280, 190, 320, 190);
  
  
  
  // nose
  
  line(300, 200, 300, 230);
  
  
  
  // mouth
  
  fill(255, 100, 120);
  
  arc(300, 250, 60, 30, 0, PI);
  
  
  
  // body
  
  fill(100, 150, 255);
  
  rect(250, 310, 100, 80);
  
  fill(255, 150, 150);
  
ellipse(230, 220, 30, 20);
  
ellipse(370, 220, 30, 20);
}